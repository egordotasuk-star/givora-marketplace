-- Repair legacy inventory rows that stored the t.me NFT URL as the gift name.
-- Safe to run again: repaired names/images no longer match the update filters.
alter table public.inventory add column if not exists image_url text;

with source_rows as (
  select
    id,
    gift_name,
    gift_url,
    coalesce(nullif(trim(gift_url), ''), gift_name) as source_url
  from public.inventory
  where gift_name ~* '^https?://t\.me/nft/'
     or (
       nullif(trim(image_url), '') is null
       and gift_url ~* '^https?://t\.me/nft/'
     )
), parsed as (
  select
    id,
    gift_name,
    gift_url,
    source_url,
    regexp_replace(
      split_part(split_part(source_url, '?', 1), '#', 1),
      '^.*/',
      ''
    ) as slug
  from source_rows
), normalized as (
  select
    id,
    gift_name,
    gift_url,
    source_url,
    slug,
    initcap(trim(regexp_replace(
      regexp_replace(
        regexp_replace(slug, '-[0-9]+$', ''),
        '([a-z0-9])([A-Z])',
        '\1 \2',
        'g'
      ),
      '[-_]+',
      ' ',
      'g'
    ))) as display_name
  from parsed
)
update public.inventory as i
set
  gift_url = coalesce(nullif(trim(i.gift_url), ''), n.source_url),
  gift_name = case
    when i.gift_name ~* '^https?://t\.me/nft/'
      then coalesce(nullif(n.display_name, ''), 'Telegram Gift')
    else i.gift_name
  end,
  image_url = case
    when nullif(trim(i.image_url), '') is null
     and n.slug ~ '^[A-Za-z0-9_-]+$'
      then 'https://nft.fragment.com/gift/' || lower(n.slug) || '.large.jpg'
    else i.image_url
  end
from normalized as n
where i.id = n.id;
