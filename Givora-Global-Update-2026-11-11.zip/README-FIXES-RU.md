# Givora — багфикс инвентаря

## Что исправлено

- Инвентарь больше не пытается показывать `https://t.me/nft/...` как файл изображения. Для таких ссылок используется превью Fragment.
- Если старое поле названия содержит ссылку на подарок, интерфейс показывает название из slug, например `Mood Pack`.
- При ошибке `Неизвестный API endpoint` интерфейс объясняет, что Edge Function `givora-api` ещё не обновлена.
- Миграция `003_inventory_display_fix.sql` исправляет старые строки инвентаря с URL вместо названия и добавляет отсутствующие URL превью.

## Что нужно выпустить

1. В GitHub загрузить обновлённый `app.js`, `supabase/migrations/003_inventory_display_fix.sql`, `MIGRATION-003-RU.sql` и этот файл. Render автоматически обновит статический сайт.
2. В Supabase SQL Editor один раз выполнить `supabase/migrations/003_inventory_display_fix.sql`. Если миграция `002_givora_unified_features.sql` ещё не выполнялась, выполнить её до `003`.
3. В Supabase → Edge Functions → `givora-api` развернуть полный код из `supabase/functions/givora-api/index.ts`. В GitHub код уже содержит маршрут `/api/inventory/{id}/publish`, но Render не разворачивает Supabase-функции автоматически.
4. Закрыть и заново открыть Telegram Mini App, проверить вкладки инвентаря и выставление подарка.

Givora Stars остаются внутренними тестовыми единицами. Выставление и покупка виртуальной карточки не выполняют передачу реального Telegram NFT.
